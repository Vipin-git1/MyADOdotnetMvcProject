using CRUDUSINGADONET.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace CRUDUSINGADONET.Controllers
{
    public class HomeController : Controller
    {
        private readonly EmployeeDataAccessLayer dal;
        public HomeController()
        {
            dal = new EmployeeDataAccessLayer();
        }
        //RC-on Index add Razor view with List
        public IActionResult Index()
        {
            List<Employee> emps = dal.getAllEmployees();
            return View(emps);
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        [AutoValidateAntiforgeryToken]
        //RC-on Create add Razor view with Create
        public IActionResult Create(Employee emp)
        {
            try
            {
                dal.AddEmployee(emp);
                return RedirectToAction("Index");
            }
            catch (Exception)
            {

                return View();
            }
        }
        public IActionResult Edit(int id)
        {
            Employee emp = dal.GetEmployeeById(id);
            return View(emp);
        }
        [HttpPost]
        [AutoValidateAntiforgeryToken]
        //RC-on Edit add Razor view with Edit
        public IActionResult Edit(Employee emp)
        {
            try
            {
                dal.UpdateEmployee(emp);
                return RedirectToAction("Index");
            }
            catch (Exception)
            {

                return View();
            }
        }
        //RC-on Details add Razor view with Details
        public IActionResult Details(int id)
        {
            Employee emp = dal.GetEmployeeById(id);
            return View(emp);
        }
        public IActionResult Delete(int id)
        {
            Employee emp = dal.GetEmployeeById(id);
            return View(emp);
        }
        [HttpPost]
        [AutoValidateAntiforgeryToken]
        //RC-on Delete add Razor view with Delete
        public IActionResult Delete(Employee emp)
        {
            try
            {
                dal.DeleteEmployee(emp.Id);
                return RedirectToAction("Index");
            }
            catch (Exception)
            {

                return View();
            }
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
