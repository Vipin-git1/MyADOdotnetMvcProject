﻿namespace CRUDUSINGADONET
{
    public class ConnectionString
    {
        public static string cs = "Server=DESKTOP-2JMKUEA\\SQLEXPRESS;Database=CrudADOdb;Trusted_Connection=True;";
        public static string dbcs { get => cs; }
    }
}
