﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentPortal.Web.Data;
using StudentPortal.Web.Models;
using StudentPortal.Web.Models.Entities;

namespace StudentPortal.Web.Controllers
{
    public class StudentController : Controller
    {
        private readonly ApplicationDbContext dbContext;
        public StudentController(ApplicationDbContext dbContext)
        {
            this.dbContext = dbContext;
        }
        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Add(AddStudentViewModel viewModel)
        {
            var student = new Student
            {
                Name = viewModel.Name,
                Email = viewModel.Email,
                Phone = viewModel.Phone,
                Subscribed = viewModel.Subscribed
            };
            await dbContext.Students.AddAsync(student);
            await dbContext.SaveChangesAsync();
            return View();
        }
        [HttpGet]
        public async Task<IActionResult> List()
        {
           var students= await dbContext.Students.ToListAsync();
            return View(students);
        }
        [HttpGet]
        public async Task<IActionResult> Edit(Guid id)
        {
            var student = await dbContext.Students.FindAsync(id);
            return View(student);
        }
        //public  IActionResult Edit(Guid id)
        //{
        //    var student = dbContext.Students.FirstOrDefault(s => s.Id == id);
        //    if (student == null)
        //    {
        //        return NotFound("Not Found");
        //    }
        //    return View(student);
        //}

        [HttpPost]
        //[HttpPut]
        public async Task<IActionResult> Edit(Student viewModel)
        {
            var student = await dbContext.Students.FirstOrDefaultAsync(x => x.Id == viewModel.Id);
            if (student is not null)
            {
                student.Name = viewModel.Name;
                student.Email = viewModel.Email;
                student.Phone = viewModel.Phone;
                student.Subscribed = viewModel.Subscribed;
                dbContext.Students.Update(student);
                await dbContext.SaveChangesAsync();
            }
            return RedirectToAction("List", "Students");
        }
        //public  IActionResult Edit(Guid id,Student viewModel)
        //{
            
        //    if (id != viewModel.Id)
        //    {
        //        return BadRequest("ID mismatch.");
        //    }
        //    var student = dbContext.Students.FirstOrDefaultAsync(x => x.Id == id);
            
        //        //student.Id = viewModel.Name;
        //        //student.Email = viewModel.Email;
        //        //student.Phone = viewModel.Phone;
        //        //student. = viewModel.Subscribed;

        //         dbContext.SaveChanges();
            
        //    return RedirectToAction("List");
        //}
        [HttpPost]
        public async Task<IActionResult> Delete(Student viewModel)
        {
            var student = await dbContext.Students
                .AsNoTracking()
                .FirstOrDefaultAsync(x=>x.Id==viewModel.Id);
            if(student is not null)
            {
                dbContext.Students.Remove(viewModel);
                await dbContext.SaveChangesAsync();
            }
            return RedirectToAction("List", "Students");
        }
    }
}
